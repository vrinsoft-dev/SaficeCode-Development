import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { clientComponent } from './client.component';

describe('IconsComponent', () => {
  let component: clientComponent;
  let fixture: ComponentFixture<clientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ clientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(clientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
