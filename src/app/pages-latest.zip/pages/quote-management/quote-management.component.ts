import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quote-management',
  templateUrl: './quote-management.component.html',
  styleUrls: ['./quote-management.component.scss']
})
export class QuoteManagementComponent implements OnInit {

  public copy: string;
  constructor() { }

  ngOnInit() {
  }

}
