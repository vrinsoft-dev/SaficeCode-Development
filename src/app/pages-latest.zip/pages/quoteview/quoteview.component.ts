import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quoteview',
  templateUrl: './quoteview.component.html',
  styleUrls: ['./quoteview.component.css']
})
export class QuoteviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
