import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-management',
  templateUrl: './client-management.component.html',
  styleUrls: ['./client-management.component.scss']
})
export class ClientManagementComponent implements OnInit {

  public copy: string;
  constructor() { }

  ngOnInit() {
  }
}
