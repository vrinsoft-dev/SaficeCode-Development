import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maps',
  templateUrl: './client-edit.component.html',
  styleUrls: ['./client-edit.component.scss']
})
export class ClienteditComponent implements OnInit {

  public copy: string;
  constructor() { }

  ngOnInit() {
  }
}